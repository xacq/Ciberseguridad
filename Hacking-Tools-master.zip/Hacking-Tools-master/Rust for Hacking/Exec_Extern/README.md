### Execute winapi functions without using windows or winapi crates by calling the functins from the External Library ie original lib that was written in C/C++.
