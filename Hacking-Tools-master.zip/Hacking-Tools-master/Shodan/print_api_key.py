import os

shodan_api_key = os.environ['SHODAN_API_KEY']
print(shodan_api_key)
