import os

nmap_command="nmap -sT 127.0.0.1"

os.system(nmap_command)
